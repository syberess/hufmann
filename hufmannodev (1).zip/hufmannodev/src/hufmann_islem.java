
public class hufmann_islem {

}
