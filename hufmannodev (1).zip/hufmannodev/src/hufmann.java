
public class hufmann {

}
